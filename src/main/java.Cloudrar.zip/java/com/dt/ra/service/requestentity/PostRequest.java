package com.dt.ra.service.requestentity;

public class PostRequest {

	private String requestBody;
	private String callbackURI;
	private String startDate;
	private String endDate;
	private String pkiKeyID;
	private String certificateType;
	private int certificateId;
	private int hashdata;

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public String getCallbackURI() {
		return callbackURI;
	}

	public void setCallbackURI(String callbackURI) {
		this.callbackURI = callbackURI;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getHashdata() {
		return hashdata;
	}

	public String getPkiKeyID() {
		return pkiKeyID;
	}

	public void setPkiKeyID(String pkiKeyID) {
		this.pkiKeyID = pkiKeyID;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public void setHashdata(int hashdata) {
		this.hashdata = hashdata;
	}

	public int getCertificateId() {
		return certificateId;
	}

	public void setCertificateId(int certificateId) {
		this.certificateId = certificateId;
	}

	@Override
	public String toString() {
		return "PostRequest [requestBody=" + requestBody + ", callbackURI=" + callbackURI
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", pkiKeyID=" + pkiKeyID + ", certificateType="
				+ certificateType + ", certificateId=" + certificateId + ", hashdata=" + hashdata + "]";
	}

}

// + "\"HSMPlugin\"" + ":" + "\"" + HSMPlugin + "\","
// + "\"CAPlugin\"" + ":" + "\"" + CAPlugin + "\""

package com.dt.ra.service.enums;

public enum CertificateStatus {
	Active, Revoked, Expired
}

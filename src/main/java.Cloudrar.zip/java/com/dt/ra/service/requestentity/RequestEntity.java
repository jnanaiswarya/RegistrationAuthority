package com.dt.ra.service.requestentity;

public class RequestEntity {

	private PostRequest postRequest;
	// private RevokeCertificatePostRequest revokeCertificatePostRequest;
	// private SetPinPostRequest setPin;
	// private GenerateSignaturePostRequest generateSignaturePostRequest;
	// private String serialNumber;
	private String transactionType;

	public PostRequest getPostRequest() {
		return postRequest;
	}

	public void setPostRequest(PostRequest postRequest) {
		this.postRequest = postRequest;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "RequestEntity [postRequest=" + postRequest + ", transactionType=" + transactionType + "]";
	}

}

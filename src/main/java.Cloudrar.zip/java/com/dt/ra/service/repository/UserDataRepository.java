package com.dt.ra.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dt.ra.service.model.RAPKIUserdata;

public interface UserDataRepository extends JpaRepository<RAPKIUserdata, Integer>{

	RAPKIUserdata findByusername(String username);

	void deleteByusername(String username);
	
	RAPKIUserdata findByemail(String email);

	@Query("SELECT COUNT(u) FROM RAPKIUserdata u")
	int getUsersCount();
}

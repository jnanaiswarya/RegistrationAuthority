package com.dt.ra.service.ifaceimplementation;

import java.security.MessageDigest;
import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.dt.ra.service.asserts.RAServiceAsserts;
import com.dt.ra.service.enums.CertificateType;
import com.dt.ra.service.exception.RAServiceException;
import com.dt.ra.service.iface.RASubscriberServiceIface;
import com.dt.ra.service.model.RAPKISubscriberdata;
import com.dt.ra.service.repository.RaSubscriberRepository;
import com.dt.ra.service.requestentity.SubscriberDataRequest;

@Component
@Transactional
@Service
public class RASubscriberServiceIfaceImpl implements RASubscriberServiceIface {

	@Autowired
	RaSubscriberRepository raSubscriberRepository;

	@Override
	public String enrollSubscriber(SubscriberDataRequest subscriberData) throws RAServiceException {
		RAPKISubscriberdata raPKISubscriberData = new RAPKISubscriberdata();

		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			raPKISubscriberData.setRaOrganizationId(subscriberData.getRaOrganizationId());
			raPKISubscriberData.setSubscriberDigitalId(subscriberData.getSubscriberDigitalId());
			raPKISubscriberData.setSubscriberUsername(subscriberData.getSubscriberUsername());
			raPKISubscriberData.setSubscriberMobileNumber(subscriberData.getSubscriberMobileNumber());
			raPKISubscriberData.setSubscriberEmailId(subscriberData.getSubscriberEmailId());
			raPKISubscriberData.setNin(subscriberData.getNin());
			raPKISubscriberData.setSubscriberStatus(subscriberData.getSubscriberStatus());
			switch (subscriberData.getCertificateType()) {
			case "Both":
				raPKISubscriberData.setCertificateType(CertificateType.Both);
				break;
			case "AuthenticationCertificate":
				raPKISubscriberData.setCertificateType(CertificateType.AuthenticationCertificate);
				break;
			case "SigningCertificate":
				raPKISubscriberData.setCertificateType(CertificateType.SigningCertificate);
				break;
			default:
				throw new RAServiceException("Certificate type not found ");
			}
			raPKISubscriberData.setPkiUsername(subscriberData.getSubscriberDigitalId());
			raPKISubscriberData
					.setPkiUsernameHash(digest.digest(subscriberData.getSubscriberDigitalId().getBytes()).toString());
			raPKISubscriberData.setPkiPassword("Aa1.123456");
			raPKISubscriberData.setPkiPasswordHash(digest.digest("Aa1.123456".getBytes()).toString());
			raPKISubscriberData.setCommonName(subscriberData.getSubscriberDigitalId());
			raPKISubscriberData.setSerialNumber(subscriberData.getSubscriberDigitalId());
			raPKISubscriberData.setCountryName("Uganda");
			raPKISubscriberData.setCertificateId(0);
			if (null != subscriberData.getCustomAttributes())
				raPKISubscriberData.setCustomAttributes(subscriberData.getCustomAttributes());
			raPKISubscriberData.setCreationDate(new String(new Timestamp(System.currentTimeMillis()).toString()));
			raPKISubscriberData.setModificationDate(null);
			raSubscriberRepository.save(raPKISubscriberData);
			return "Success";
		} catch (Exception e) {
			throw new RAServiceException(e.getMessage());
		}
	}

	@Override
	public List<RAPKISubscriberdata> getAllSubscriberDetails() throws RAServiceException {
		List<RAPKISubscriberdata> raSubscriberData = raSubscriberRepository.findAll();
		RAServiceAsserts.notNullorEmpty(raSubscriberData.size(), "Subscriber details ");
		return raSubscriberData;
	}

	@Override
	public RAPKISubscriberdata getSubscriberDetailsBySubscriberDigitalId(String subscriberDigitalId)
			throws RAServiceException {
		RAPKISubscriberdata raSubscriberData = raSubscriberRepository.findBysubscriberDigitalId(subscriberDigitalId);
		RAServiceAsserts.notNullorEmpty(raSubscriberData, "SubscriberDigitalId ", "not found");
		return raSubscriberData;
	}

	@Override
	public List<RAPKISubscriberdata> getSubscriberDetailsByOrganizationId(int raOrganizationId)
			throws RAServiceException {
		List<RAPKISubscriberdata> raSubscriberData = raSubscriberRepository.findByraOrganizationId(raOrganizationId);
		RAServiceAsserts.notNullorEmpty(raSubscriberData.size(), "OrganizationId ");
		return raSubscriberData;
	}

	@Override
	public int getSubscriberCount() {
		return raSubscriberRepository.getSubscriberCount();
	}
}
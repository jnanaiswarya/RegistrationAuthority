package com.dt.ra.service.requestentity;

public class RevokeCertificateRequest {

	private String serialNumber;
	private String reasonId;

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getReasonId() {
		return reasonId;
	}

	public void setReasonId(String reasonId) {
		this.reasonId = reasonId;
	}

	@Override
	public String toString() {
		return "{" + "\"serial_number\"" + ":" + "\"" + serialNumber + "\"," + "\"reason\"" + ":" + "\"" + reasonId + "\""
				+ "}";
	}

}

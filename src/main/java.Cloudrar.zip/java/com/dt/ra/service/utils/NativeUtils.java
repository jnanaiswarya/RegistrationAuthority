package com.dt.ra.service.utils;

import java.security.NoSuchAlgorithmException;
import java.util.Random;
import java.util.UUID;

public class NativeUtils {
	static UUID uuid;

	static String upperAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	static String lowerAlphabet = "abcdefghijklmnopqrstuvwxyz";
	static String numbers = "0123456789";

	public static String generatePKIKeyId() {
		String alphaNumeric = upperAlphabet;
		return genRandomNumber(alphaNumeric);
	}
	
	private static String genRandomNumber(String alphaNumeric) {
		StringBuilder sb = new StringBuilder();
		Random random = new Random();

		// specify length of random string
		int length = 10;

		for (int i = 0; i < length; i++) {

			// generate random index number
			int index = random.nextInt(alphaNumeric.length());

			// get character specified by index
			// from the string
			char randomChar = alphaNumeric.charAt(index);

			// append the character to string builder
			sb.append(randomChar);
		}
		return sb.toString();
	}
	public static String generateCorelationId() {
		uuid = UUID.randomUUID();
		return uuid.toString();
	}

	public static String generateTransactionId() {
		uuid = UUID.randomUUID();
		return uuid.toString();
	}

	public static boolean validateRequestBody(String requestBody, int hashdata) throws NoSuchAlgorithmException {
		if (hashdata == requestBody.hashCode())
			return true;
		else
			return false;
	}
}

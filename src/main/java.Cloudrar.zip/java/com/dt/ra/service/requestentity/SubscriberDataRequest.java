package com.dt.ra.service.requestentity;

public class SubscriberDataRequest {
	private int raOrganizationId;
	private String subscriberDigitalId;
	private String subscriberUsername;
	private String subscriberMobileNumber;
	private String subscriberEmailId;
	private String nin;
	private String subscriberStatus;
	private String certificateType;
	private String customAttributes;

	public int getRaOrganizationId() {
		return raOrganizationId;
	}

	public void setRaOrganizationId(int raOrganizationId) {
		this.raOrganizationId = raOrganizationId;
	}

	public String getSubscriberDigitalId() {
		return subscriberDigitalId;
	}

	public void setSubscriberDigitalId(String subscriberDigitalId) {
		this.subscriberDigitalId = subscriberDigitalId;
	}

	public String getSubscriberUsername() {
		return subscriberUsername;
	}

	public void setSubscriberUsername(String subscriberUsername) {
		this.subscriberUsername = subscriberUsername;
	}

	public String getSubscriberMobileNumber() {
		return subscriberMobileNumber;
	}

	public void setSubscriberMobileNumber(String subscriberMobileNumber) {
		this.subscriberMobileNumber = subscriberMobileNumber;
	}

	public String getSubscriberEmailId() {
		return subscriberEmailId;
	}

	public void setSubscriberEmailId(String subscriberEmailId) {
		this.subscriberEmailId = subscriberEmailId;
	}

	public String getCustomAttributes() {
		return customAttributes;
	}

	public void setCustomAttributes(String customAttributes) {
		this.customAttributes = customAttributes;
	}

	public String getNin() {
		return nin;
	}

	public void setNin(String nin) {
		this.nin = nin;
	}

	public String getSubscriberStatus() {
		return subscriberStatus;
	}

	public void setSubscriberStatus(String subscriberStatus) {
		this.subscriberStatus = subscriberStatus;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	@Override
	public String toString() {
		return "SubscriberDataRequest [raOrganizationId=" + raOrganizationId + ", subscriberDigitalId="
				+ subscriberDigitalId + ", subscriberUsername=" + subscriberUsername + ", subscriberMobileNumber="
				+ subscriberMobileNumber + ", subscriberEmailId=" + subscriberEmailId + ", nin=" + nin
				+ ", subscriberStatus=" + subscriberStatus + ", certificateType=" + certificateType
				+ ", customAttributes=" + customAttributes + "]";
	}
}

package com.dt.ra.service.requestentity;

public class SetPinPostRequest {
	private String requestBody;
	private int hashdata;

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public int getHashdata() {
		return hashdata;
	}

	public void setHashdata(int hashdata) {
		this.hashdata = hashdata;
	}

	@Override
	public String toString() {
		return "SetPinPostRequest [requestBody=" + requestBody + ", hashdata=" + hashdata + "]";
	}

}

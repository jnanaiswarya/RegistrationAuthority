package com.dt.ra.service.requestentity;

public class CheckCertificateStatusPostRequest {

	private String requestBody;
	private int hashdata;

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public void setHashdata(int hashdata) {
		this.hashdata = hashdata;
	}

	public int getHashdata() {
		return hashdata;
	}

	@Override
	public String toString() {
		return "CheckCertificateStatusPostRequest [requestBody=" + requestBody + ", hashdata=" + hashdata + "]";
	}

}

// + "\"HSMPlugin\"" + ":" + "\"" + HSMPlugin + "\","
// + "\"CAPlugin\"" + ":" + "\"" + CAPlugin + "\""

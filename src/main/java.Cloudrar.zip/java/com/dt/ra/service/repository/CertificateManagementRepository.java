package com.dt.ra.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dt.ra.service.model.RAPKISubscriberdata;
import com.dt.ra.service.model.Subscribercertificatemanagementdata;

public interface CertificateManagementRepository extends JpaRepository<Subscribercertificatemanagementdata, Integer> {

	Subscribercertificatemanagementdata findBycoorelationId(String id);
	
	List<Subscribercertificatemanagementdata> findByraPKISubscriberData(RAPKISubscriberdata id);
	
}

package com.dt.ra.service.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dt.ra.service.asserts.RAServiceAsserts;
import com.dt.ra.service.ifaceimplementation.SignatureServiceIfaceImpl;
import com.dt.ra.service.requestentity.GenerateSignatureRequest;
import com.dt.ra.service.requestentity.SetPinRequest;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/SignatureServcie")
public class SignatureServiceController {

	@Autowired
	SignatureServiceIfaceImpl signatureServiceIfaceImpl;

	@PostMapping(value = "/setPin/", consumes = "application/json")
	public String setPin(@RequestBody SetPinRequest setPin) {
		try {
			RAServiceAsserts.notNullorEmpty(setPin, "SetPin");
			return signatureServiceIfaceImpl.setPin(setPin);
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}
	
	@PostMapping(value = "/generateSignature/", consumes = "application/json")
	public String generateSignature(@RequestBody  GenerateSignatureRequest generateSignatureRequest) {
		try {
			RAServiceAsserts.notNullorEmpty(generateSignatureRequest, "SetPin");
			return signatureServiceIfaceImpl.generateSignature(generateSignatureRequest);
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}
}

package com.dt.ra.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dt.ra.service.enums.CertificateStatus;
import com.dt.ra.service.enums.CertificateType;
import com.dt.ra.service.model.RAPKISubscribercertificatedata;
import com.dt.ra.service.model.RAPKISubscriberdata;

public interface RaSubscriberCertificateRepository extends JpaRepository<RAPKISubscribercertificatedata, Integer> {

	List<RAPKISubscribercertificatedata> findBysubscriberCertId(int subscriberCertId);

	List<RAPKISubscribercertificatedata> findByraPKISubscriberData(RAPKISubscriberdata raPKISubscriberData);

	RAPKISubscribercertificatedata findBycertificateSerialNumber(String certificateSerialNumber);

	List<RAPKISubscribercertificatedata> findBycertificateType(CertificateType certificateType);

	List<RAPKISubscribercertificatedata> findBycertificateStatus(CertificateStatus status);

	@Query("SELECT COUNT(u) FROM RAPKISubscribercertificatedata u")
	int getCertificateCount();
}

package com.dt.ra.service.requestentity;

public class UpdatePaymentRequest {
	private String subscriberDigitalId;
	private String paymentStatus;
	private String status;

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getSubscriberDigitalId() {
		return subscriberDigitalId;
	}

	public void setSubscriberDigitalId(String subscriberDigitalId) {
		this.subscriberDigitalId = subscriberDigitalId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "UpdatePaymentRequest [subscriberDigitalId=" + subscriberDigitalId + ", paymentStatus=" + paymentStatus
				+ ", status=" + status + "]";
	}

}

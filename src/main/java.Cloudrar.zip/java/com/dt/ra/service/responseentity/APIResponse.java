package com.dt.ra.service.responseentity;

public class APIResponse {
	private boolean status;
	private String message;
	private String result;

	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "{" + "\"success\"" + ":" + status + "," + "\"message\"" + ":" + "\"" + message + "\","
				+ "\"result\"" + ":" + result + "}";
	}
}

package com.dt.ra.service.requestentity;

public class IssueCertificateRequest {
	private int certificateID;
	private String subscriberDigitalID;
	private String username;
	private String password;
	private String keyID;
	private String startDate;
	private String endDate;
	private String certificateSerialNumber;
	private boolean renewCertRequest;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getKeyID() {
		return keyID;
	}

	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}

	public int getCertificateID() {
		return certificateID;
	}

	public void setCertificateID(int certificateID) {
		this.certificateID = certificateID;
	}

	public String getSubscriberDigitalID() {
		return subscriberDigitalID;
	}

	public void setSubscriberDigitalID(String subscriberDigitalID) {
		this.subscriberDigitalID = subscriberDigitalID;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getCertificateSerialNumber() {
		return certificateSerialNumber;
	}

	public void setCertificateSerialNumber(String certificateSerialNumber) {
		this.certificateSerialNumber = certificateSerialNumber;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public boolean getRenewCertRequest() {
		return renewCertRequest;
	}

	public void setRenewCertRequest(boolean renewCertRequest) {
		this.renewCertRequest = renewCertRequest;
	}

	@Override
	public String toString() {
		return "{" + "\"subscriberDigitalID\"" + ":" + "\"" + subscriberDigitalID + "\"," + "\"username\"" + ":" + "\""
				+ username + "\"," + "\"password\"" + ":" + "\"" + password + "\"," + "\"keyID\"" + ":" + "\"" + keyID
				+ "\"," + "\"certificateID\"" + ":" + certificateID + "," + "\"start_date\"" + ":" + "\"" + startDate
				+ "\"," + "\"end_date\"" + ":" + "\"" + endDate + "\","+ "\"renew_cert_request\"" + ":" + renewCertRequest + "}";
	}

}
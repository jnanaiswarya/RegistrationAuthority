package com.dt.ra.service.ifaceimplementation;

import java.util.LinkedHashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dt.ra.service.exception.RAServiceException;
import com.dt.ra.service.iface.SignatureServiceIface;
import com.dt.ra.service.model.RAPKISubscribercertificatedata;
import com.dt.ra.service.model.RAPKISubscriberdata;
import com.dt.ra.service.repository.RaSubscriberCertificateRepository;
import com.dt.ra.service.repository.RaSubscriberRepository;
import com.dt.ra.service.requestentity.GenerateSignatureRequest;
import com.dt.ra.service.requestentity.PostRequest;
import com.dt.ra.service.requestentity.RequestEntity;
import com.dt.ra.service.requestentity.SetPinRequest;
import com.dt.ra.service.utils.PropertiesConstants;

@Component
@Transactional
@Service
public class SignatureServiceIfaceImpl implements SignatureServiceIface {

	@Autowired
	RestTemplate restTemplate;
	@Autowired
	RaSubscriberRepository raSubscriberRepository;
	@Autowired
	RaSubscriberCertificateRepository raSubscriberCertificateRepository;

	@Override
	public String setPin(SetPinRequest setPin) throws Exception {
		try {
			RAPKISubscriberdata rapkiSubscriberdata = raSubscriberRepository
					.findBysubscriberDigitalId(setPin.getSubscriberDigitalID());
			if (null == rapkiSubscriberdata)
				throw new RAServiceException("SubscriberDigitalId not found");
			setPin.setUsername(rapkiSubscriberdata.getPkiUsername());
			setPin.setPassword(rapkiSubscriberdata.getPkiPassword());
			List<RAPKISubscribercertificatedata> rapkiSubscribercertificatedata = raSubscriberCertificateRepository
					.findByraPKISubscriberData(rapkiSubscriberdata);
			for (RAPKISubscribercertificatedata data : rapkiSubscribercertificatedata) {
				if (data.getCertificateId() == setPin.getCertificateId()) {
					setPin.setKeyID(data.getPkiKeyId());
				}
			}
			PostRequest setPinPostRequest = new PostRequest();
			setPinPostRequest.setRequestBody(setPin.toString());
			setPinPostRequest.setHashdata(setPin.toString().hashCode());
			RequestEntity requestEntity = new RequestEntity();
			requestEntity.setPostRequest(setPinPostRequest);
			requestEntity.setTransactionType("SetPin");
			String baseUrl = PropertiesConstants.PKIURL;
			ResponseEntity<String> httpResponse = restTemplate.postForEntity(baseUrl, requestEntity, String.class);
			System.out.println("HttpResponse :: " + httpResponse.getBody());
			if (httpResponse.getBody().equals("Internal Server Error Occured"))
				return httpResponse.getBody();
			JSONParser parser = new JSONParser(httpResponse.getBody());
			LinkedHashMap<String, Object> json = parser.object();
			String status = json.get("status").toString();
			if (status.equals("fail")) {
				return json.get("error_message").toString();
			} else {
				return json.get("status").toString();
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public String generateSignature(GenerateSignatureRequest generateSignatureRequest) throws Exception {
		RAPKISubscriberdata rapkiSubscriberdata = raSubscriberRepository
				.findBysubscriberDigitalId(generateSignatureRequest.getSubscriberDigitalID());
		if (null == rapkiSubscriberdata)
			throw new RAServiceException("SubscriberDigitalId not found");
		generateSignatureRequest.setPassword(rapkiSubscriberdata.getPkiPassword());
		List<RAPKISubscribercertificatedata> rapkiSubscribercertificatedata = raSubscriberCertificateRepository
				.findByraPKISubscriberData(rapkiSubscriberdata);
		for (RAPKISubscribercertificatedata data : rapkiSubscribercertificatedata) {
			if (data.getCertificateId() == generateSignatureRequest.getCertificateId()) {
				generateSignatureRequest.setKeyID(data.getPkiKeyId());
			}
		}
		PostRequest generateSignaturePostRequest = new PostRequest();
		generateSignaturePostRequest.setRequestBody(generateSignatureRequest.toString());
		generateSignaturePostRequest.setHashdata(generateSignatureRequest.toString().hashCode());

		try {
			RequestEntity requestEntity = new RequestEntity();
			requestEntity.setPostRequest(generateSignaturePostRequest);
			requestEntity.setTransactionType("GenerateSignature");
			String baseUrl = PropertiesConstants.PKIURL;
			ResponseEntity<String> httpResponse = restTemplate.postForEntity(baseUrl, requestEntity, String.class);
			System.out.println("Response :: " + httpResponse.getBody());
			JSONParser parser = new JSONParser(httpResponse.getBody());
			LinkedHashMap<String, Object> json = parser.object();
			String status = json.get("status").toString();
			if (status.equals("fail")) {
				return json.get("error_message").toString();
			} else {
				return httpResponse.getBody();
			}
		} catch (Exception e) {
			throw new Exception("PKITransaction Handler Service not running");
		}

	}
}

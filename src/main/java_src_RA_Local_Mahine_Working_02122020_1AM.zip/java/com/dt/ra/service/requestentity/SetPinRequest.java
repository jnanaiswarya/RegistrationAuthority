package com.dt.ra.service.requestentity;

public class SetPinRequest {
	private String subscriberDigitalID;
	private String password;
	private String keyID;
	private String signingPassword;
	private String username;
	private int certificateId;

	public int getCertificateId() {
		return certificateId;
	}

	public void setCertificateId(int certificateId) {
		this.certificateId = certificateId;
	}

	public String getSubscriberDigitalID() {
		return subscriberDigitalID;
	}

	public void setSubscriberDigitalID(String subscriberDigitalID) {
		this.subscriberDigitalID = subscriberDigitalID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getKeyID() {
		return keyID;
	}

	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}

	public String getSigningPassword() {
		return signingPassword;
	}

	public void setSigningPassword(String signingPassword) {
		this.signingPassword = signingPassword;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "{" + "\"subscriberDigitalID\"" + ":" + "\"" + subscriberDigitalID + "\"," + "\"username\"" + ":" + "\""
				+ username + "\"," + "\"password\"" + ":" + "\"" + password + "\"," + "\"keyID\"" + ":" + "\"" + keyID
				+ "\"," + "\"signingPassword\"" + ":" + "\"" + signingPassword + "\"" + "}";
	}

}

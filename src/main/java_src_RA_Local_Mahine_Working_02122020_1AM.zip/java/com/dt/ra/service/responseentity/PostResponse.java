package com.dt.ra.service.responseentity;

public class PostResponse {
	private String response;
	private String coId;

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getCoId() {
		return coId;
	}

	public void setCoId(String coId) {
		this.coId = coId;
	}

	@Override
	public String toString() {
		return "{" + "\"Response \"" + ":" + response + "," + "\"CoId \"" + ":" + coId + "," + "}";
	}

}

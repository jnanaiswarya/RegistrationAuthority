package com.dt.ra.service.responseentity;

import java.io.Serializable;

public class UpdatePaymentResponse implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int statusCode;
	private String status;
	private String paymentStaus;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPaymentStaus() {
		return paymentStaus;
	}

	public void setPaymentStaus(String paymentStaus) {
		this.paymentStaus = paymentStaus;
	}

	@Override
	public String toString() {
		return "{" 
					+ "\"StatusCode\"" 			+ ":" + "\"" + statusCode 				+ "\"," 
					+ "\"Status\"" 					+ ":" + "\"" + status						+ "\","
					+ "\"PaymentStaus\"" 		+ ":" + "\"" +  paymentStaus + "\""
					+ "}";
	}


}

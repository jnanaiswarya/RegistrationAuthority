package com.dt.ra.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dt.ra.service.model.RAPKISubscriberdata;

public interface RaSubscriberRepository extends JpaRepository<RAPKISubscriberdata, Integer> {

	List<RAPKISubscriberdata> findByraOrganizationId(int organizationId);

	RAPKISubscriberdata findBysubscriberDigitalId(String subscriberDigitalId);
	
	RAPKISubscriberdata findBysubscriberId(RAPKISubscriberdata data);

	@Query("SELECT COUNT(u) FROM RAPKISubscriberdata u")
	int getSubscriberCount();
}

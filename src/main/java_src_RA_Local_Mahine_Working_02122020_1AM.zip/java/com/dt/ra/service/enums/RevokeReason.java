package com.dt.ra.service.enums;

public enum RevokeReason {
	AffiliationChanged, CertificateHold, KeyCompromised, CessationOfOperation, NoReason, Privilegewithdrawn, Superseded
}

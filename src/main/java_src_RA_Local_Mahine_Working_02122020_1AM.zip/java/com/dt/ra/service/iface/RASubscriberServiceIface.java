package com.dt.ra.service.iface;

import java.util.List;

import com.dt.ra.service.exception.RAServiceException;
import com.dt.ra.service.model.RAPKISubscriberdata;
import com.dt.ra.service.requestentity.SubscriberDataRequest;

public interface RASubscriberServiceIface {

	String enrollSubscriber(SubscriberDataRequest subscriberData) throws RAServiceException;

	List<RAPKISubscriberdata> getAllSubscriberDetails() throws RAServiceException;

	RAPKISubscriberdata getSubscriberDetailsBySubscriberDigitalId(String subscriberDigitalId) throws RAServiceException;

	List<RAPKISubscriberdata> getSubscriberDetailsByOrganizationId(int raOrganizationId) throws RAServiceException;

	int getSubscriberCount();
}

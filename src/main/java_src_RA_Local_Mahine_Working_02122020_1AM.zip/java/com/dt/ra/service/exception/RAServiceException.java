package com.dt.ra.service.exception;

public class RAServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RAServiceException(String message) {
		super(message);
	}
}

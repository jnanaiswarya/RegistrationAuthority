package com.dt.ra.service.iface;

import com.dt.ra.service.exception.RAServiceException;
import com.dt.ra.service.requestentity.GenerateSignatureRequest;
import com.dt.ra.service.requestentity.SetPinRequest;

public interface SignatureServiceIface {

	public String setPin(SetPinRequest setPin) throws RAServiceException, Exception;

	String generateSignature(GenerateSignatureRequest setPin) throws Exception;
}

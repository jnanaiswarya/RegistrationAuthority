package com.dt.ra.service.ifaceimplementation;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;

import javax.sql.rowset.serial.SerialException;
import javax.transaction.Transactional;

import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dt.ra.service.asserts.RAServiceAsserts;
import com.dt.ra.service.dao.CentralLogRepository;
import com.dt.ra.service.enums.CertificateStatus;
import com.dt.ra.service.enums.CertificateType;
import com.dt.ra.service.enums.RevokeReason;
import com.dt.ra.service.exception.RAServiceException;
import com.dt.ra.service.iface.RAServiceIface;
import com.dt.ra.service.model.DownloadCerts;
import com.dt.ra.service.model.LogModel;
import com.dt.ra.service.model.RAPKISubscribercertificatedata;
import com.dt.ra.service.model.RAPKISubscriberdata;
import com.dt.ra.service.model.Subscribercertificatemanagementdata;
import com.dt.ra.service.repository.CertificateManagementRepository;
import com.dt.ra.service.repository.RaSubscriberCertificateRepository;
import com.dt.ra.service.repository.RaSubscriberRepository;
import com.dt.ra.service.requestentity.IssueCertificateRequest;
import com.dt.ra.service.requestentity.PostRequest;
import com.dt.ra.service.requestentity.RequestEntity;
import com.dt.ra.service.requestentity.RevokeCertificateRequest;
import com.dt.ra.service.utils.NativeUtils;
import com.dt.ra.service.utils.PropertiesConfiguration;
import com.dt.ra.service.utils.PropertiesConstants;

@Component
@Transactional
@Service
public class RAServiceIfaceImpl implements RAServiceIface {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	PropertiesConfiguration configuration;
	@Autowired
	RaSubscriberCertificateRepository raSubscriberCertificateRepository;
	@Autowired
	RaSubscriberRepository raSubscriberRepository;
	@Autowired
	CertificateManagementRepository certificateManagementRepository;
	@Autowired
	CentralLogRepository centralLogRepository;

	@Override
	public String issueCertificate(IssueCertificateRequest issueCertificateRequest)
			throws RAServiceException, Exception {
		RAPKISubscriberdata raPKISubscriberData = raSubscriberRepository
				.findBysubscriberDigitalId(issueCertificateRequest.getSubscriberDigitalID());
		if (null == raPKISubscriberData)
			throw new RAServiceException("SubscriberDigitalId not found");
		if ("InActive".equals(raPKISubscriberData.getSubscriberStatus()))
			throw new RAServiceException("Given SubscriberDigitalId is InActive");
		List<RAPKISubscribercertificatedata> rapkiSubscribercertificatedata = raSubscriberCertificateRepository
				.findByraPKISubscriberData(raPKISubscriberData);
		issueCertificateRequest.setUsername(raPKISubscriberData.getPkiUsername());
		PostRequest issueCertificatePostRequest = new PostRequest();
		issueCertificateRequest.setRenewCertRequest(false);
		LogModel logModel = new LogModel();
		logModel.setStartTime(new String(new Timestamp(System.currentTimeMillis()).toString()));
		try {
			if (rapkiSubscribercertificatedata.size() == 0) {
				issueCertificateRequest.setPassword(raPKISubscriberData.getPkiPassword());
				System.out.println(PropertiesConstants.ISSUECERTIFICATECALLBACKURL);
				issueCertificatePostRequest.setCallbackURI(PropertiesConstants.ISSUECERTIFICATECALLBACKURL);
				issueCertificatePostRequest.setStartDate(issueCertificateRequest.getStartDate());
				issueCertificatePostRequest.setEndDate(issueCertificateRequest.getEndDate());
				String baseUrl = PropertiesConstants.PKIURL;
				if (raPKISubscriberData.getCertificateType().toString() == "SigningCertificate") {
					String keyId = NativeUtils.generatePKIKeyId();
					issueCertificateRequest.setKeyID(keyId);
					issueCertificateRequest.setCertificateID(raPKISubscriberData.getCertificateId());
					issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
					issueCertificatePostRequest.setPkiKeyID(keyId);
					issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
					issueCertificatePostRequest.setCertificateType(raPKISubscriberData.getCertificateType().toString());
					String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
							logModel);
					String[] resp = response.split("\n");
					if (resp[0].equals("Success")) {
						return "Request for issuing SigningCertificate process successfully";
					} else {
						throw new RAServiceException("Request for issuing SigningCertificate process failed");
					}
				} else if (raPKISubscriberData.getCertificateType().toString() == "AuthenticationCertificate") {
					String keyId = NativeUtils.generatePKIKeyId();
					issueCertificateRequest.setKeyID(keyId);
					issueCertificateRequest.setCertificateID(raPKISubscriberData.getCertificateId());
					issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
					issueCertificatePostRequest.setPkiKeyID(keyId);
					issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
					issueCertificatePostRequest.setCertificateType(raPKISubscriberData.getCertificateType().toString());
					String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
							logModel);
					String resp[] = response.split("\n");
					if (resp[0].equals("Success")) {
						return "Request for issuing AuthenticationCertificate process successfully";
					} else {
						throw new RAServiceException("Request for issuing AuthenticationCertificate process failed");
					}
				} else if (raPKISubscriberData.getCertificateType().toString() == "Both") {
					String keyId = NativeUtils.generatePKIKeyId();
					issueCertificateRequest.setKeyID(keyId);
					issueCertificateRequest.setCertificateID(raPKISubscriberData.getCertificateId());
					issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
					issueCertificatePostRequest.setPkiKeyID(keyId);
					issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
					issueCertificatePostRequest.setCertificateType(CertificateType.SigningCertificate.toString());
					String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
							logModel);
					String[] resp = response.split("\n");
					if (resp[0].equals("Success")) {
						System.out.println("Request for issuing SigningCertificate process Successfully");
						String keyId2 = NativeUtils.generatePKIKeyId();
						issueCertificateRequest.setKeyID(keyId2);
						issueCertificateRequest.setCertificateID(1);
						issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
						issueCertificatePostRequest.setPkiKeyID(keyId2);
						issueCertificateRequest.setCertificateID(1);
						issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
						issueCertificatePostRequest
								.setCertificateType(CertificateType.AuthenticationCertificate.toString());
						String response2 = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
								logModel);
						String resp1[] = response2.split("\n");
						if (resp1[0].equals("Success")) {
							return "Request for issuing SigningCertificate and AuthenticationCertificate process successfully";
						} else {
							throw new RAServiceException(
									"Request for issuing AuthenticationCertificate process failed");
						}
					} else {
						throw new RAServiceException("Request for issuing SigningCertificate process failed");
					}
				}
			} else {
				List<RAPKISubscribercertificatedata> signCertData = new ArrayList<RAPKISubscribercertificatedata>();
				List<RAPKISubscribercertificatedata> authCertData = new ArrayList<RAPKISubscribercertificatedata>();
				for (RAPKISubscribercertificatedata certdata : rapkiSubscribercertificatedata) {
					if (certdata.getCertificateType().equals(CertificateType.SigningCertificate))
						signCertData.add(certdata);
					else
						authCertData.add(certdata);
				}
				issueCertificateRequest.setPassword(raPKISubscriberData.getPkiPassword());
				issueCertificateRequest.setCertificateID(raPKISubscriberData.getCertificateId() + 1);
				issueCertificatePostRequest.setCallbackURI(PropertiesConstants.ISSUECERTIFICATECALLBACKURL);
				issueCertificatePostRequest.setStartDate(issueCertificateRequest.getStartDate());
				issueCertificatePostRequest.setEndDate(issueCertificateRequest.getEndDate());
				issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
				String baseUrl = PropertiesConstants.PKIURL;
				if (raPKISubscriberData.getCertificateType().toString() == "SigningCertificate") {
					boolean isActive = false;
					for (RAPKISubscribercertificatedata sa : signCertData) {
						if (sa.getCertificateStatus().equals(CertificateStatus.Active))
							isActive = true;
					}
					if (!isActive) {
						String keyId = NativeUtils.generatePKIKeyId();
						issueCertificateRequest.setKeyID(keyId);
						issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
						issueCertificatePostRequest.setPkiKeyID(keyId);
						issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
						issueCertificatePostRequest.setCertificateType(CertificateType.SigningCertificate.toString());
						String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
								logModel);
						String resp[] = response.split("\n");
						if (resp[0].equals("Success")) {
							return "Request for issuing SigningCertificate process successfully";
						} else {
							throw new RAServiceException("Request for issuing SigningCertificate process failed");
						}
					} else {
						return "Signing Certificate allready issued and its active";
					}
				}
				if (raPKISubscriberData.getCertificateType().toString() == "AuthenticationCertificate") {
					boolean isActive = false;
					for (RAPKISubscribercertificatedata sa : authCertData) {
						if (sa.getCertificateStatus().equals(CertificateStatus.Active))
							isActive = true;
					}
					if (!isActive) {
						String keyId = NativeUtils.generatePKIKeyId();
						issueCertificateRequest.setKeyID(keyId);
						issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
						issueCertificatePostRequest.setPkiKeyID(keyId);
						issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
						issueCertificatePostRequest
								.setCertificateType(CertificateType.AuthenticationCertificate.toString());
						String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
								logModel);
						String resp[] = response.split("\n");
						if (response.equals("Success")) {
							return "Request for issuing AuthenticationCertificate process successfully";
						} else {
							throw new RAServiceException(
									"Request for issuing AuthenticationCertificate process failed");
						}
					} else {
						return "Certificates allready issued and its active";
					}

				}
				if (raPKISubscriberData.getCertificateType().toString() == "Both") {
					if (0 == signCertData.size()) {
						String keyId = NativeUtils.generatePKIKeyId();
						issueCertificateRequest.setKeyID(keyId);
						issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
						issueCertificatePostRequest.setPkiKeyID(keyId);
						issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
						issueCertificatePostRequest.setCertificateType(CertificateType.SigningCertificate.toString());
						String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
								logModel);
						String resp[] = response.split("\n");
						if (resp[0].equals("Success")) {
							return "Request for issuing SigningCertificate process successfully";
						} else {
							throw new RAServiceException("Request for issuing SigningCertificate process failed");
						}
					} else {
						boolean isActive = false;
						for (RAPKISubscribercertificatedata sa : signCertData) {
							if (sa.getCertificateStatus().equals(CertificateStatus.Active))
								isActive = true;
						}
						if (!isActive) {
							String keyId = NativeUtils.generatePKIKeyId();
							issueCertificateRequest.setKeyID(keyId);
							issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
							issueCertificatePostRequest.setPkiKeyID(keyId);
							issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
							issueCertificatePostRequest
									.setCertificateType(CertificateType.SigningCertificate.toString());
							String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
									logModel);
							String resp[] = response.split("\n");
							if (resp[0].equals("Success")) {
								return "Request for issuing SigningCertificate process successfully";
							} else {
								throw new RAServiceException("Request for issuing SigningCertificate process failed");
							}
						} else {
							System.out.println("Signing Certificate allready issued and its active");
						}
					}

					if (0 == authCertData.size()) {
						String keyId = NativeUtils.generatePKIKeyId();
						issueCertificateRequest.setKeyID(keyId);
						issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
						issueCertificatePostRequest.setPkiKeyID(keyId);
						issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
						issueCertificatePostRequest
								.setCertificateType(CertificateType.AuthenticationCertificate.toString());
						String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
								logModel);
						String resp[] = response.split("\n");
						if (resp[0].equals("Success")) {
							return "Request for issuing AuthenticationCertificate process successfully";
						} else {
							throw new RAServiceException(
									"Request for issuing AuthenticationCertificate process failed");
						}
					} else {
						boolean isActive = false;
						for (RAPKISubscribercertificatedata sa : authCertData) {
							if (sa.getCertificateStatus().equals(CertificateStatus.Active))
								isActive = true;
						}
						if (!isActive) {
							String keyId = NativeUtils.generatePKIKeyId();
							issueCertificateRequest.setKeyID(keyId);
							issueCertificatePostRequest.setRequestBody(issueCertificateRequest.toString());
							issueCertificatePostRequest.setPkiKeyID(keyId);
							issueCertificatePostRequest.setHashdata(issueCertificateRequest.toString().hashCode());
							issueCertificatePostRequest
									.setCertificateType(CertificateType.AuthenticationCertificate.toString());
							String response = processRequest(baseUrl, issueCertificatePostRequest, raPKISubscriberData,
									logModel);
							String resp[] = response.split("\n");
							if (resp[0].equals("Success")) {
								return "Request for issuing AuthenticationCertificate process successfully";
							} else {
								throw new RAServiceException(
										"Request for issuing AuthenticationCertificate process failed");
							}
						} else {
							return "Certificates allready issued and its active";
						}
					}
				}
			}
		} catch (Exception e) {
			throw new RAServiceException(e.getMessage());
		}
		return null;
	}

	private String processRequest(String baseUrl, PostRequest issueCertificatePostRequest,
			RAPKISubscriberdata rapkiSubscriberdata, LogModel logModel) throws Exception {
		ResponseEntity<String> httpResponse = null;
		try {

			logModel.setIdentifier(rapkiSubscriberdata.getSubscriberMobileNumber());
			logModel.setNin(rapkiSubscriberdata.getNin());
			logModel.setCorrelationId(NativeUtils.generateCorelationId());
			logModel.setTransactionId(NativeUtils.generateTransactionId());
			logModel.setGeolocation("");
			logModel.setServiceName("PKI");
			logModel.setTransactionType("Issue Certificate");
			logModel.setLogMessage("Issue Certificate  API request");
			logModel.setLogMessageType("Request");
			String requestbody = issueCertificatePostRequest.getRequestBody();
			logModel.setCallstack(requestbody);
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] encodedhash = digest.digest(requestbody.getBytes(StandardCharsets.UTF_8));
			String base64 = Base64.getEncoder().encodeToString(encodedhash);
			logModel.setChecksum(base64);
			issueCertificatePostRequest.setRequestBody(logModel.toString());
			issueCertificatePostRequest.setHashdata(logModel.toString().hashCode());
			RequestEntity requestEntity = new RequestEntity();
			requestEntity.setPostRequest(issueCertificatePostRequest);
			requestEntity.setTransactionType("IssueCertificate");
			httpResponse = restTemplate.postForEntity(baseUrl, requestEntity, String.class);
			RAServiceAsserts.notNullorEmpty(httpResponse, "Http response ");
			if (httpResponse.getBody().equals("Request is not Valid"))
				throw new RAServiceException("Request Data is tampered");
			Subscribercertificatemanagementdata subscriberCertificateManagementData = new Subscribercertificatemanagementdata();
			subscriberCertificateManagementData.setCoorelationId(httpResponse.getBody());
			subscriberCertificateManagementData.setRaPKISubscriberData(rapkiSubscriberdata);
			certificateManagementRepository.save(subscriberCertificateManagementData);
			return "Success" + "\n" + httpResponse.getBody();
		} catch (RAServiceException e) {
			throw new RAServiceException(e.getMessage());
		}

	}

	@Override
	public String checkCertificateStatus(String serialNumber) throws RAServiceException {
		try {
			RAPKISubscribercertificatedata rapkiSubscribercertificatedata = raSubscriberCertificateRepository
					.findBycertificateSerialNumber(serialNumber);
			if (null == rapkiSubscribercertificatedata) {
				throw new RAServiceException("Certificate not found");
			}
			LogModel logModel = new LogModel();
			logModel.setIdentifier(rapkiSubscribercertificatedata.getRaPKISubscriberData().getSubscriberMobileNumber());
			logModel.setNin(rapkiSubscribercertificatedata.getRaPKISubscriberData().getNin());
			logModel.setCorrelationId(NativeUtils.generateCorelationId());
			logModel.setTransactionId(NativeUtils.generateTransactionId());
			logModel.setGeolocation("");
			logModel.setServiceName("PKI");
			logModel.setTransactionType("CheckCertificateStatus");
			logModel.setLogMessage("CheckCertificateStatus  API response");
			logModel.setLogMessageType("Request");
			logModel.setStartTime(new String(new Timestamp(System.currentTimeMillis()).toString()));
			String requestbody = "{\"serial_number\"" + ":" + "\""
					+ rapkiSubscribercertificatedata.getCertificateSerialNumber() + "\"}";
			logModel.setCallstack(requestbody);
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] encodedhash = digest.digest(requestbody.getBytes(StandardCharsets.UTF_8));
			String base64 = Base64.getEncoder().encodeToString(encodedhash);
			logModel.setChecksum(base64);
			String baseUrl = PropertiesConstants.PKIURL;
			PostRequest request = new PostRequest();
			request.setRequestBody(logModel.toString());
			request.setHashdata(logModel.toString().hashCode());
			try {
				RequestEntity requestEntity = new RequestEntity();
				requestEntity.setPostRequest(request);
				requestEntity.setTransactionType("CertificateStatus");
				ResponseEntity<String> httpResponse = null;
				try {
					httpResponse = restTemplate.postForEntity(baseUrl, requestEntity, String.class);
				} catch (Exception e) {
					throw new Exception("PKITransaction Handler Service not running");
				}
				if ("Request is not Valid".equals(httpResponse.getBody()))
					throw new RAServiceException(httpResponse.getBody());
				String[] response = httpResponse.getBody().split("\n");
				JSONParser parser = new JSONParser(response[0]);
				LinkedHashMap<String, Object> json = parser.object();
				String status = json.get("status").toString();
				logModel.setLogMessage("Check Certificate Status API response");
				if (status.equals("fail")) {
					// logModel.setLogMessageType("FAILED");
					// NativeUtils.logMgmt(response[1], logModel);
					throw new RAServiceException(json.get("error_message").toString());
				} else {
					// logModel.setLogMessageType("SUCCESS");
					// logModel.setCorrelationId(coId);
					// logModel.setTransactionId(centralLog.getTransactionId());
					// logModel.setEndTime(centralLog.getEndTime());
					// logModel.setStartTime(centralLog.getStartTime());
					// logModel.setCallstack(centralLog.getRequest());
					// System.out.println(response[1]);
					// NativeUtils.logMgmt(response[1], logModel);
					return json.get("revocation_reason").toString();
				}
			} catch (Exception e) {
				throw new RAServiceException(e.getMessage());
			}

		} catch (Exception e) {
			throw new RAServiceException(e.getMessage());
		}
	}

	@Override
	public String revokeCertificate(RevokeCertificateRequest requestBody) throws RAServiceException, ParseException {
		RAPKISubscribercertificatedata rapkiSubscribercertificatedata = raSubscriberCertificateRepository
				.findBycertificateSerialNumber(requestBody.getSerialNumber());
		RAServiceAsserts.notNullorEmpty(rapkiSubscribercertificatedata, "Certificate ", "not found");
		if (rapkiSubscribercertificatedata.getCertificateStatus().equals(CertificateStatus.Revoked))
			throw new RAServiceException("Certificate allready Revoked");
		LogModel logModel = new LogModel();
		logModel.setStartTime(new String(new Timestamp(System.currentTimeMillis()).toString()));
		requestBody.setSerialNumber(rapkiSubscribercertificatedata.getCertificateSerialNumber());
		switch (requestBody.getReasonId()) {
		case "1":
			requestBody.setReasonId(requestBody.getReasonId());
			rapkiSubscribercertificatedata.setRevocationReason(RevokeReason.KeyCompromised);
			break;
		case "-2":
			requestBody.setReasonId(requestBody.getReasonId());
			rapkiSubscribercertificatedata.setRevocationReason(RevokeReason.NoReason);
		case "3":
			requestBody.setReasonId(requestBody.getReasonId());
			rapkiSubscribercertificatedata.setRevocationReason(RevokeReason.AffiliationChanged);
			break;
		case "4":
			requestBody.setReasonId(requestBody.getReasonId());
			rapkiSubscribercertificatedata.setRevocationReason(RevokeReason.Superseded);
			break;
		case "5":
			requestBody.setReasonId(requestBody.getReasonId());
			rapkiSubscribercertificatedata.setRevocationReason(RevokeReason.CessationOfOperation);
			break;
		case "6":
			requestBody.setReasonId(requestBody.getReasonId());
			rapkiSubscribercertificatedata.setRevocationReason(RevokeReason.CertificateHold);
			break;
		case "9":
			requestBody.setReasonId(requestBody.getReasonId());
			rapkiSubscribercertificatedata.setRevocationReason(RevokeReason.Privilegewithdrawn);
			break;
		default:
			throw new RAServiceException("Revoke reason not found");
		}
		logModel.setIdentifier(rapkiSubscribercertificatedata.getRaPKISubscriberData().getSubscriberMobileNumber());
		logModel.setNin(rapkiSubscribercertificatedata.getRaPKISubscriberData().getNin());
		logModel.setCorrelationId(NativeUtils.generateCorelationId());
		logModel.setTransactionId(NativeUtils.generateTransactionId());
		logModel.setGeolocation("");
		logModel.setServiceName("PKI");
		logModel.setTransactionType("Revoke Certificate");
		logModel.setLogMessage("Revoke Certificate  API response");
		logModel.setLogMessageType("Request");

		String requestbody = requestBody.toString();
		logModel.setCallstack(requestbody);
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance("SHA-256");
			byte[] encodedhash = digest.digest(requestbody.getBytes(StandardCharsets.UTF_8));
			String base64 = Base64.getEncoder().encodeToString(encodedhash);
			logModel.setChecksum(base64);
		} catch (NoSuchAlgorithmException e1) {
			throw new RAServiceException(e1.getMessage());
		}
		String baseUrl = PropertiesConstants.PKIURL;
		PostRequest request = new PostRequest();
		request.setRequestBody(logModel.toString());
		request.setHashdata(logModel.toString().hashCode());
		RequestEntity requestEntity = new RequestEntity();
		requestEntity.setPostRequest(request);
		requestEntity.setTransactionType("RevokeCertificate");
		ResponseEntity<String> httpResponse;
		try {
			httpResponse = restTemplate.postForEntity(baseUrl, requestEntity, String.class);
		} catch (Exception e) {
			throw new RAServiceException(e.getMessage() + "PKI Service not running");
		}
		JSONParser parser = new JSONParser(httpResponse.getBody());
		LinkedHashMap<String, Object> json = parser.object();
		String status = json.get("status").toString();
		if (status.equals("fail"))
			return status;
		else {
			rapkiSubscribercertificatedata.setCertificateStatus(CertificateStatus.Revoked);
			rapkiSubscribercertificatedata
					.setRevocationDate(new String(new Timestamp(System.currentTimeMillis()).toString()));

			rapkiSubscribercertificatedata
					.setModificationDate(new String(new Timestamp(System.currentTimeMillis()).toString()));
			raSubscriberCertificateRepository.save(rapkiSubscribercertificatedata);
			Subscribercertificatemanagementdata subscribercertificatemanagementdata = new Subscribercertificatemanagementdata();
			subscribercertificatemanagementdata.setCertificateSerialNumber(requestBody.getSerialNumber());
			subscribercertificatemanagementdata.setCertificateStatus(CertificateStatus.Revoked.toString());
			subscribercertificatemanagementdata
					.setRaPKISubscriberData(rapkiSubscribercertificatedata.getRaPKISubscriberData());
			subscribercertificatemanagementdata
					.setCreationDate(new String(new Timestamp(System.currentTimeMillis()).toString()));
			certificateManagementRepository.save(subscribercertificatemanagementdata);
			return status;
		}
	}

	@Override
	public void issueCertificateCallBack(String[] response) throws SerialException, SQLException, RAServiceException {
		Subscribercertificatemanagementdata subscriberCertificateManagementData = certificateManagementRepository
				.findBycoorelationId(response[1]);
		RAServiceAsserts.notNullorEmpty(subscriberCertificateManagementData, "CoorelationId");
		RAPKISubscriberdata rapkiSubscriberData = subscriberCertificateManagementData.getRaPKISubscriberData();
		RAServiceAsserts.notNullorEmpty(rapkiSubscriberData, "SubscriberData");
		JSONParser parser = new JSONParser(response[0]);
		LinkedHashMap<String, Object> json;
		RAPKISubscribercertificatedata rapkiSubscriberCertificateData = new RAPKISubscribercertificatedata();
		try {
			json = parser.object();
			String status = json.get("status").toString();
			if (status.equals("success")) {
				rapkiSubscriberCertificateData.setPkiKeyId(response[4]);
				rapkiSubscriberCertificateData.setCertificateData(json.get("certificate").toString());
				rapkiSubscriberCertificateData.setCertificateStatus(CertificateStatus.Active);
				switch (response[5]) {
				case "AuthenticationCertificate":
					rapkiSubscriberCertificateData.setCertificateType(CertificateType.AuthenticationCertificate);
					break;
				case "SigningCertificate":
					rapkiSubscriberCertificateData.setCertificateType(CertificateType.SigningCertificate);
					break;
				case "Both":
					rapkiSubscriberCertificateData.setCertificateType(CertificateType.Both);
					break;
				default:
					throw new RAServiceException("Certificate Type not found");
				}
				rapkiSubscriberCertificateData
						.setCertificateSerialNumber(json.get("certificate_serial_number").toString());
				rapkiSubscriberCertificateData.setRevocationReason(null);
				rapkiSubscriberCertificateData.setStartDate(response[2]);
				rapkiSubscriberCertificateData.setEndDate(response[3]);
				rapkiSubscriberCertificateData.setRevocationDate(null);
				rapkiSubscriberCertificateData
						.setCreationDate(new String(new Timestamp(System.currentTimeMillis()).toString()));
				rapkiSubscriberCertificateData.setRaPKISubscriberData(rapkiSubscriberData);
				raSubscriberCertificateRepository.save(rapkiSubscriberCertificateData);
				raSubscriberRepository.save(rapkiSubscriberData);
				subscriberCertificateManagementData
						.setCertificateSerialNumber(json.get("certificate_serial_number").toString());
				subscriberCertificateManagementData.setCertificateStatus(CertificateStatus.Active.toString());
				subscriberCertificateManagementData
						.setCreationDate(new String(new Timestamp(System.currentTimeMillis()).toString()));
				certificateManagementRepository.save(subscriberCertificateManagementData);
				System.out
						.println("Certificate issued for " + rapkiSubscriberData.getSubscriberDigitalId() + " success");
			} else {
				subscriberCertificateManagementData.setCertificateStatus(response[0]);
				subscriberCertificateManagementData
						.setCreationDate(new String(new Timestamp(System.currentTimeMillis()).toString()));
				certificateManagementRepository.save(subscriberCertificateManagementData);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String downloadCertificateBySubscriberDigitalID(String subscriberDigitalID)
			throws RAServiceException, SQLException {
		try {
			RAPKISubscriberdata rapkiSubscriberdata = raSubscriberRepository
					.findBysubscriberDigitalId(subscriberDigitalID);
			RAServiceAsserts.notNullorEmpty(rapkiSubscriberdata, "SubscriberDigitalId not found");
			List<RAPKISubscribercertificatedata> raSubscriberCertData = raSubscriberCertificateRepository
					.findByraPKISubscriberData(rapkiSubscriberdata);
			if (raSubscriberCertData.size() == 0)
				throw new RAServiceException("SubscriberDigitalId Not Found");
			List<DownloadCerts> certificateList = new ArrayList<DownloadCerts>();
			for (RAPKISubscribercertificatedata raSubscriberCert : raSubscriberCertData) {
				if (raSubscriberCert.getCertificateStatus().equals(CertificateStatus.Active)) {
					DownloadCerts downloadCerts = new DownloadCerts();
					downloadCerts.setCertificates(raSubscriberCert.getCertificateData());
					certificateList.add(downloadCerts);
				}
			}
			return certificateList.toString();
		} catch (RAServiceException e) {
			throw new RAServiceException(e.getMessage());
		}
	}

	@Override
	public int getCertificateCount() {
		return raSubscriberCertificateRepository.getCertificateCount();
	}

	@Override
	public String getCertificateDetails() throws RAServiceException {
		List<RAPKISubscribercertificatedata> rapkiSubscribercertificatedata = raSubscriberCertificateRepository
				.findAll();
		RAServiceAsserts.notNullorEmpty(rapkiSubscribercertificatedata.size(), "No certificate found");
		List<RAPKISubscribercertificatedata> rapkiSubscribercertificate = new ArrayList<RAPKISubscribercertificatedata>();
		for (RAPKISubscribercertificatedata certData : rapkiSubscribercertificatedata) {
			RAPKISubscribercertificatedata certificateData = new RAPKISubscribercertificatedata();
			certificateData.setCertificateSerialNumber(certData.getCertificateSerialNumber());
			certificateData.setCertificateStatus(certData.getCertificateStatus());
			certificateData.setCertificateType(certData.getCertificateType());
			certificateData.setModificationDate(certData.getModificationDate());
			certificateData.setEndDate(certData.getEndDate());
			certificateData.setStartDate(certData.getStartDate());
			certificateData.setPkiKeyId(certData.getRaPKISubscriberData().getSubscriberUsername());
			certificateData.setSubscriberCertId(certData.getSubscriberCertId());
			rapkiSubscribercertificate.add(certificateData);
		}
		return rapkiSubscribercertificate.toString();
	}

	@Override
	public int getCertificateCountByDate() throws RAServiceException {
		List<RAPKISubscribercertificatedata> count = raSubscriberCertificateRepository.findAll();
		RAServiceAsserts.notNullorEmpty(count.size(), "No Certificate found");
		int certCount = 0;
		String Date = new String(new Timestamp(System.currentTimeMillis()).toString());
		String[] dateSplit = Date.split(" ");
		for (RAPKISubscribercertificatedata data : count) {
			String dates = data.getCreationDate();
			String[] datesSplit = dates.split(" ");
			if (dateSplit[0].equals(datesSplit[0]))
				certCount = certCount + 1;
		}
		return certCount;
	}

	@Override
	public String getCertificateLifecycleLogs() throws RAServiceException {
		List<Subscribercertificatemanagementdata> subscribercertificatemanagementdatas = certificateManagementRepository
				.findAll();
		RAServiceAsserts.notNullorEmpty(subscribercertificatemanagementdatas.size(), "Certificate logs");
		List<Subscribercertificatemanagementdata> data = new ArrayList<Subscribercertificatemanagementdata>();
		for (Subscribercertificatemanagementdata datas : subscribercertificatemanagementdatas) {
			if (datas.getCertificateSerialNumber() != null) {
				Subscribercertificatemanagementdata subscribercertificatemanagementdata = new Subscribercertificatemanagementdata();
				subscribercertificatemanagementdata.setCertificateSerialNumber(datas.getCertificateSerialNumber());
				subscribercertificatemanagementdata.setCertificateStatus(datas.getCertificateStatus());

				String dates = datas.getCreationDate();
				String[] datesSplit = dates.split(" ");
				subscribercertificatemanagementdata.setCreationDate(datesSplit[0]);
				subscribercertificatemanagementdata
						.setCertificateManagementId(datas.getRaPKISubscriberData().getSubscriberId());
				data.add(subscribercertificatemanagementdata);
			}
		}
		return data.toString();
	}

	@Override
	public String getCertificateLifeCycleLogsBySubscriberId(RAPKISubscriberdata id) throws RAServiceException {
		List<Subscribercertificatemanagementdata> subscribercertificatemanagementdatas = certificateManagementRepository
				.findByraPKISubscriberData(id);
		RAServiceAsserts.notNullorEmpty(subscribercertificatemanagementdatas.size(), "Certificate logs");
		List<Subscribercertificatemanagementdata> data = new ArrayList<Subscribercertificatemanagementdata>();
		for (Subscribercertificatemanagementdata datas : subscribercertificatemanagementdatas) {
			if (datas.getCertificateSerialNumber() != null) {
				Subscribercertificatemanagementdata subscribercertificatemanagementdata = new Subscribercertificatemanagementdata();
				subscribercertificatemanagementdata.setCertificateSerialNumber(datas.getCertificateSerialNumber());
				subscribercertificatemanagementdata.setCertificateStatus(datas.getCertificateStatus());
				String dates = datas.getCreationDate();
				String[] datesSplit = dates.split(" ");
				subscribercertificatemanagementdata.setCreationDate(datesSplit[0]);
				subscribercertificatemanagementdata
						.setCertificateManagementId(datas.getRaPKISubscriberData().getSubscriberId());
				data.add(subscribercertificatemanagementdata);
			}
		}
		return data.toString();
	}

	public String getRevokeReasons() {
		String str = "[{" + "\"index\" 		: \"1\"," + "\"reason\" 	 : \"KEY_COMPROMISED\"" + "}," + "{"
				+ "\"index\" 		: \"-2\"," + "\"reason\" 	 : \"NO_REASON_CODE\"" + "}," + "{"
				+ "\"index\" 		: \"3\"," + "\"reason\" 	 : \"AFFILIATION_CHANGED\"" + "}," + "{"
				+ "\"index\" 		: \"4\"," + "\"reason\" 	 : \"SUPERSEDED\"" + "}," + "{"
				+ "\"index\" 		: \"5\"," + "\"reason\" 	 : \"CESSATION_OF_OPERATION\"" + "}," + "{"
				+ "\"index\" 		: \"6\"," + "\"reason\" 	 : \"CERTIFICATE_HOLD\"" + "}," + "{"
				+ "\"index\" 		: \"9\"," + "\"reason\" 	 : \"PRIVILEGE_WITHDRAWN\"" + "}]";
		return str;

	}

	@Override
	public String getCertificateDetailsBySubscriberCertId(int id) throws RAServiceException {
		List<RAPKISubscribercertificatedata> rapkiSubscribercertificatedata = raSubscriberCertificateRepository
				.findBysubscriberCertId(id);
		RAServiceAsserts.notNullorEmpty(rapkiSubscribercertificatedata.size(), "No certificate found");
		List<RAPKISubscribercertificatedata> rapkiSubscribercertificate = new ArrayList<RAPKISubscribercertificatedata>();
		for (RAPKISubscribercertificatedata certData : rapkiSubscribercertificatedata) {
			RAPKISubscribercertificatedata certificateData = new RAPKISubscribercertificatedata();
			certificateData.setCertificateSerialNumber(certData.getCertificateSerialNumber());
			certificateData.setCertificateStatus(certData.getCertificateStatus());
			certificateData.setCertificateType(certData.getCertificateType());
			certificateData.setModificationDate(certData.getModificationDate());
			certificateData.setEndDate(certData.getEndDate());
			certificateData.setStartDate(certData.getStartDate());
			certificateData.setPkiKeyId(certData.getRaPKISubscriberData().getSubscriberUsername());
			rapkiSubscribercertificate.add(certificateData);
		}
		return rapkiSubscribercertificate.toString();
	}

	@Override
	public String renewCertificate(IssueCertificateRequest requestBody) throws RAServiceException, Exception {
		try {

			RAServiceAsserts.notNullorEmpty(requestBody.getCertificateSerialNumber(), "Certificate Serial Number");
			RAPKISubscribercertificatedata rapkiSubscribercertificatedata = raSubscriberCertificateRepository
					.findBycertificateSerialNumber(requestBody.getCertificateSerialNumber());
			RAServiceAsserts.notNullorEmpty(rapkiSubscribercertificatedata, "Certificate data");
			String status1 = rapkiSubscribercertificatedata.getCertificateStatus().toString();
			if (status1 == "Active")
				throw new Exception("Certificate is Active");

			if (status1 == "Revoked")
				throw new Exception("Certificate is Revoked");
			LogModel logModel = new LogModel();
			logModel.setStartTime(new String(new Timestamp(System.currentTimeMillis()).toString()));
			String baseUrl = PropertiesConstants.PKIURL;
			String certSerialNumber = rapkiSubscribercertificatedata.getCertificateSerialNumber();
			PostRequest request = new PostRequest();
			request.setRequestBody(certSerialNumber);
			request.setHashdata(request.toString().hashCode());
			try {
				RequestEntity requestEntity = new RequestEntity();
				requestEntity.setPostRequest(request);
				requestEntity.setTransactionType("CertificateStatus");
				ResponseEntity<String> httpResponse = null;
				try {
					httpResponse = restTemplate.postForEntity(baseUrl, requestEntity, String.class);
				} catch (Exception e) {
					throw new Exception("PKITransaction Handler Service not running");
				}
				JSONParser parser = new JSONParser(httpResponse.getBody());
				LinkedHashMap<String, Object> json = parser.object();
				String status = json.get("status").toString();
				if (status.equals("fail")) {
					throw new RAServiceException("Request failed");
				} else {
					RAPKISubscriberdata rapkiSubscriberdata = rapkiSubscribercertificatedata.getRaPKISubscriberData();
					requestBody.setCertificateID(1);
					requestBody.setKeyID(rapkiSubscribercertificatedata.getPkiKeyId());
					requestBody.setUsername(rapkiSubscriberdata.getPkiUsername());
					requestBody.setPassword(rapkiSubscriberdata.getPkiPassword());
					requestBody.setSubscriberDigitalID(rapkiSubscriberdata.getSubscriberDigitalId());
					requestBody.setRenewCertRequest(true);
					PostRequest issueCertificatePostRequest = new PostRequest();
					issueCertificatePostRequest.setCallbackURI(PropertiesConstants.ISSUECERTIFICATECALLBACKURL);
					issueCertificatePostRequest.setCertificateId(1);
					issueCertificatePostRequest
							.setCertificateType(rapkiSubscribercertificatedata.getCertificateType().toString());
					issueCertificatePostRequest.setStartDate(requestBody.getStartDate());
					issueCertificatePostRequest.setEndDate(requestBody.getEndDate());
					issueCertificatePostRequest.setRequestBody(requestBody.toString());
					issueCertificatePostRequest.setHashdata(requestBody.toString().hashCode());
					try {
						String response = processRequest(baseUrl, issueCertificatePostRequest, rapkiSubscriberdata,
								logModel);
						if (response.equals("Success"))
							return "Request for renewing " + rapkiSubscribercertificatedata.getCertificateType()
									+ " process successfully";
						else
							throw new RAServiceException("Request for issuing SigningCertificate process failed");
					} catch (Exception e) {
						throw new Exception(e.getMessage());
					}
				}
			} catch (Exception e) {
				throw new RAServiceException(e.getMessage());
			}
		} catch (Exception e) {
			throw new RAServiceException(e.getMessage());
		}
	}
}

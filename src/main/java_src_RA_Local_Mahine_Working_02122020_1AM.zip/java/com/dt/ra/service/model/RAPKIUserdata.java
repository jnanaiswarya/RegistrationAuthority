package com.dt.ra.service.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class RAPKIUserdata implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private int userId;
	@Column(unique = true, length = 20)
	private String username;
	@Column(length = 50)
	private String usernameHash;
	@Column(unique = true, length = 20)
	private String password;
	@Column(length = 50)
	private String passwordHash;
	@Column(length = 50)
	private String email;
	@Column(length = 10)
	private String role;
	@Column(length = 50)
	private String createdDate;
	@Column(length = 50)
	private String modifiedDate;
	@Column(length = 20)
	private String isPasswordChanged;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsernameHash() {
		return usernameHash;
	}

	public void setUsernameHash(String usernameHash) {
		this.usernameHash = usernameHash;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIsPasswordChanged() {
		return isPasswordChanged;
	}

	public void setIsPasswordChanged(String isPasswordChanged) {
		this.isPasswordChanged = isPasswordChanged;
	}

	@Override
	public String toString() {
		return "{" + "\"UserId\"" + ":" + "\"" + userId + "\"," + "\"IsPasswordChanged\"" + ":" + "\""
				+ isPasswordChanged + "\"," + "\"Email\"" + ":" + "\"" + email + "\"," + "\"Username\"" + ":" + "\""
				+ username + "\"," + "\"Password\"" + ":" + "\"" + password + "\"," + "\"CreatedDate\"" + ":" + "\""
				+ createdDate + "\"," + "\"ModifiedDate\"" + ":" + "\"" + modifiedDate + "\"," + "\"Role\"" + ":" + "\""
				+ role + "\"" + "}";
	}

}

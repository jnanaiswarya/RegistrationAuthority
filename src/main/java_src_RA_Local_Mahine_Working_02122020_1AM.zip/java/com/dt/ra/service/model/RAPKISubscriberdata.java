package com.dt.ra.service.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.dt.ra.service.enums.CertificateType;

@Entity
@Table
public class RAPKISubscriberdata implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private int subscriberId;
	private int raOrganizationId;
	@Column(unique = true, nullable = false, length = 50)
	private String subscriberDigitalId;
	@Column(unique = true, nullable = false, length = 25)
	private String subscriberUsername;
	@Column(unique = true, nullable = false, length = 20)
	private String subscriberMobileNumber;
	@Column(unique = true, nullable = false, length = 30)
	private String subscriberEmailId;
	@Column(length = 30)
	private String pkiUsername;
	@Column(length = 30)
	private String pkiUsernameHash;
	@Column(length = 30)
	private String pkiPassword;
	@Column(length = 30)
	private String pkiPasswordHash;
	@Column(length = 25)
	private String commonName;
	@Column(length = 25)
	private String serialNumber;
	@Column(length = 10)
	private String countryName;
	@Column(length = 100)
	@Enumerated(EnumType.STRING)
	private CertificateType certificateType;
	@Column(length = 10)
	private String subscriberStatus;
	@Column(unique = true, length = 20)
	private String nin;
	private int certificateId;
	@Column(length = 512)
	private String customAttributes;
	@Column(length = 50)
	private String creationDate;
	@Column(length = 50)
	private String modificationDate;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	private List<RAPKISubscribercertificatedata> raPKISubscriberCertificateData = new ArrayList<>();

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Subscribercertificatemanagementdata> subscriberCertificateManagementData = new ArrayList<>();

	public int getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(int subscriberId) {
		this.subscriberId = subscriberId;
	}

	public int getRaOrganizationId() {
		return raOrganizationId;
	}

	public void setRaOrganizationId(int raOrganizationId) {
		this.raOrganizationId = raOrganizationId;
	}

	public String getSubscriberDigitalId() {
		return subscriberDigitalId;
	}

	public void setSubscriberDigitalId(String subscriberDigitalId) {
		this.subscriberDigitalId = subscriberDigitalId;
	}

	public String getSubscriberUsername() {
		return subscriberUsername;
	}

	public void setSubscriberUsername(String subscriberUsername) {
		this.subscriberUsername = subscriberUsername;
	}

	public String getSubscriberMobileNumber() {
		return subscriberMobileNumber;
	}

	public void setSubscriberMobileNumber(String subscriberMobileNumber) {
		this.subscriberMobileNumber = subscriberMobileNumber;
	}

	public String getSubscriberEmailId() {
		return subscriberEmailId;
	}

	public void setSubscriberEmailId(String subscriberEmailId) {
		this.subscriberEmailId = subscriberEmailId;
	}

	public String getPkiUsername() {
		return pkiUsername;
	}

	public void setPkiUsername(String pkiUsername) {
		this.pkiUsername = pkiUsername;
	}

	public String getPkiUsernameHash() {
		return pkiUsernameHash;
	}

	public void setPkiUsernameHash(String pkiUsernameHash) {
		this.pkiUsernameHash = pkiUsernameHash;
	}

	public String getPkiPassword() {
		return pkiPassword;
	}

	public void setPkiPassword(String pkiPassword) {
		this.pkiPassword = pkiPassword;
	}

	public String getPkiPasswordHash() {
		return pkiPasswordHash;
	}

	public void setPkiPasswordHash(String pkiPasswordHash) {
		this.pkiPasswordHash = pkiPasswordHash;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public CertificateType getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(CertificateType certificateType) {
		this.certificateType = certificateType;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(String modificationDate) {
		this.modificationDate = modificationDate;
	}

	public String getSubscriberStatus() {
		return subscriberStatus;
	}

	public void setSubscriberStatus(String subscriberStatus) {
		this.subscriberStatus = subscriberStatus;
	}

	public String getCustomAttributes() {
		return customAttributes;
	}

	public void setCustomAttributes(String customAttributes) {
		this.customAttributes = customAttributes;
	}

	public String getNin() {
		return nin;
	}

	public void setNin(String nin) {
		this.nin = nin;
	}

	public int getCertificateId() {
		return certificateId;
	}

	public void setCertificateId(int certificateId) {
		this.certificateId = certificateId;
	}

	@Override
	public String toString() {
		return "{" + "\"SubscriberId\"" + " : " + "\"" + subscriberId + "\"," + "\"OrganizationId\"" + " : " + "\""
				+ raOrganizationId + "\"," + "\"SubscriberDigitalId\"" + " : " + "\"" + subscriberDigitalId + "\","
				+ "\"SubscriberUsername\"" + " : " + "\"" + subscriberUsername + "\"," + "\"SubscriberMobileNumber\""
				+ " : " + "\"" + subscriberMobileNumber + "\"," + "\"SubscriberEmailId\"" + " : " + "\""
				+ subscriberEmailId + "\"," + "\"CertificateType\"" + " : " + "\"" + certificateType + "\","
				+ "\"CreationDate\"" + " : " + "\"" + creationDate + "\"," + "\"NIN\"" + " : " + "\"" + nin + "\","
				+ "\"CertificateID\"" + " : " + "\"" + certificateId + "\"," + "\"ModificationDate\"" + " : " + "\""
				+ modificationDate + "\"" + "}";
	}

}
package com.dt.ra.service.iface;

import java.sql.SQLException;

import javax.sql.rowset.serial.SerialException;

import org.apache.tomcat.util.json.ParseException;

import com.dt.ra.service.exception.RAServiceException;
import com.dt.ra.service.model.RAPKISubscriberdata;
import com.dt.ra.service.requestentity.IssueCertificateRequest;
import com.dt.ra.service.requestentity.RevokeCertificateRequest;

public interface RAServiceIface {

	public String issueCertificate(IssueCertificateRequest requestBody) throws RAServiceException, Exception;

	public String revokeCertificate(RevokeCertificateRequest requestBody) throws RAServiceException, ParseException;

	public String downloadCertificateBySubscriberDigitalID(String subscriberDigitalID)
			throws RAServiceException, SQLException;

	public String getCertificateDetails() throws RAServiceException;

	public String getCertificateLifecycleLogs() throws RAServiceException;

	public String getCertificateLifeCycleLogsBySubscriberId(RAPKISubscriberdata id) throws RAServiceException;

	public String getCertificateDetailsBySubscriberCertId(int id) throws RAServiceException;

	public String checkCertificateStatus(String serialnumber) throws RAServiceException;

	public String renewCertificate(IssueCertificateRequest requestBody) throws RAServiceException, Exception;

	public int getCertificateCount();

	public int getCertificateCountByDate() throws RAServiceException;

	public void issueCertificateCallBack(String[] requestBody) throws SerialException, SQLException, RAServiceException;
}

package com.dt.ra.service.utils;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "ra.service")
public class PropertiesConfiguration {

	private String pki;
	private String issuecertificatecallbackurl;

	// Mail properties
	private int springmailport;
	private String springmailhost;
	private String springmailusername;
	private String springmailpassword;

	public String getPki() {
		return pki;
	}

	public void setPki(String pkiurl) {
		this.pki = pkiurl;
	}

	public String getIssuecertificatecallbackurl() {
		return issuecertificatecallbackurl;
	}

	public void setIssuecertificatecallbackurl(String issuecertificatecallbackurl) {
		this.issuecertificatecallbackurl = issuecertificatecallbackurl;
	}

	public String getSpringmailhost() {
		return springmailhost;
	}

	public void setSpringmailhost(String springmailhost) {
		this.springmailhost = springmailhost;
	}

	public int getSpringmailport() {
		return springmailport;
	}

	public void setSpringmailport(int springmailport) {
		this.springmailport = springmailport;
	}

	public String getSpringmailusername() {
		return springmailusername;
	}

	public void setSpringmailusername(String springmailusername) {
		this.springmailusername = springmailusername;
	}

	public String getSpringmailpassword() {
		return springmailpassword;
	}

	public void setSpringmailpassword(String springmailpassword) {
		this.springmailpassword = springmailpassword;
	}

}

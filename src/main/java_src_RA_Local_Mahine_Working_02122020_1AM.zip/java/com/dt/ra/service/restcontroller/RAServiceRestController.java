package com.dt.ra.service.restcontroller;

import java.sql.SQLException;

import javax.sql.rowset.serial.SerialException;

import org.apache.tomcat.util.json.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dt.ra.service.asserts.RAServiceAsserts;
import com.dt.ra.service.exception.RAServiceException;
import com.dt.ra.service.ifaceimplementation.RAServiceIfaceImpl;
import com.dt.ra.service.model.RAPKISubscriberdata;
import com.dt.ra.service.repository.RaSubscriberRepository;
import com.dt.ra.service.requestentity.IssueCertificateRequest;
import com.dt.ra.service.requestentity.RevokeCertificateRequest;
import com.dt.ra.service.responseentity.APIResponse;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/ra/service")
public class RAServiceRestController {
	@Autowired
	RaSubscriberRepository raSubscriberRepository;
	@Autowired
	RAServiceIfaceImpl raServiceIfaceImpl;

	@PostMapping(value = "/requestCertificate/", consumes = "application/json", produces = "application/json")
	public String requestCertificate(@RequestBody IssueCertificateRequest requestBody) {
		APIResponse apiResponse = new APIResponse();
		try {
			RAServiceAsserts.notNullorEmpty(requestBody, "Request Body");
			System.out.println("Post request body :: " + requestBody.toString());
			String response = raServiceIfaceImpl.issueCertificate(requestBody);
			RAServiceAsserts.notNullorEmpty(response, "Response ");
			apiResponse.setStatus(true);
			apiResponse.setMessage(response);
			return apiResponse.toString();
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.toString());
			return apiResponse.toString();
		} catch (Exception e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.toString());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/downloadCertificateBySubscriberDigitalID/{subscriberDigitalID}/", produces = "application/json")
	public String downloadCertificateBySubscriberDigitalID(@PathVariable String subscriberDigitalID) {
		APIResponse responseEntity = new APIResponse();
		try {

			RAServiceAsserts.notNullorEmpty(subscriberDigitalID, "Subscriber Digital ID ");
			String response = raServiceIfaceImpl.downloadCertificateBySubscriberDigitalID(subscriberDigitalID);
			if (response.isEmpty())
				throw new RAServiceException("Certificate Not Found");
			responseEntity.setStatus(true);
			responseEntity.setResult(response);
			return responseEntity.toString();
		} catch (RAServiceException e) {
			responseEntity.setStatus(false);
			responseEntity.setMessage(e.getMessage());
			return responseEntity.toString();
		} catch (SQLException e) {
			responseEntity.setStatus(false);
			responseEntity.setMessage(e.getMessage());
			return responseEntity.toString();
		} catch (Exception e) {
			responseEntity.setStatus(false);
			responseEntity.setMessage(e.getMessage());
			return responseEntity.toString();
		}
	}

	@GetMapping(value = "/checkCertificateStatus/{serialnumber}/", produces = "application/json")
	public String checkCertificateStatus(@PathVariable String serialnumber) {
		APIResponse apiResponse = new APIResponse();
		try {
			RAServiceAsserts.notNullorEmpty(serialnumber, "Certificate Serial number ");
			String response = raServiceIfaceImpl.checkCertificateStatus(serialnumber);
			if (response.isEmpty())
				throw new RAServiceException("Certificate Not Found");
			apiResponse.setStatus(true);
			apiResponse.setMessage(response);
			return apiResponse.toString();
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		} catch (Exception e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@PostMapping(value = "/revokeCertificate/", produces = "application/json")
	public String revokeCertificate(@RequestBody RevokeCertificateRequest requestBody) {
		APIResponse apiResponse = new APIResponse();
		try {
			RAServiceAsserts.notNullorEmpty(requestBody, "Request Body");
			String response = raServiceIfaceImpl.revokeCertificate(requestBody);
			if (response.equals("fail")) {
				throw new RAServiceException(response);
			} else {
				apiResponse.setStatus(true);
				apiResponse.setMessage("Certificate Revoke Successfully");
				return apiResponse.toString();
			}
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		} catch (ParseException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@PostMapping(value = "/renewCertificate/", produces = "application/json")
	public String renewCertificate(@RequestBody IssueCertificateRequest requestBody) {
		APIResponse apiResponse = new APIResponse();
		try {
			RAServiceAsserts.notNullorEmpty(requestBody, "Request Body");
			String response = raServiceIfaceImpl.renewCertificate(requestBody);
			if (response.equals("fail")) {
				throw new RAServiceException(response);
			} else {
				apiResponse.setStatus(true);
				apiResponse.setMessage(response);
				return apiResponse.toString();
			}
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		} catch (ParseException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		} catch (Exception e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@PostMapping(value = "/requestCertificateCallBack/")
	public void requestCertificateCallBack(@RequestBody String[] response) {
		try {
			System.out.println("Request Certificate CallBack Response :: " + response[0]);
			RAServiceAsserts.notNullorEmpty(response, "Response Body");
			raServiceIfaceImpl.issueCertificateCallBack(response);
		} catch (RAServiceException e) {
			e.printStackTrace();
		} catch (SerialException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@GetMapping(value = "/getCertificateCount", produces = "application/json")
	public String getCertificateCount() {
		APIResponse apiResponse = new APIResponse();
		try {
			Integer count = raServiceIfaceImpl.getCertificateCount();
			apiResponse.setStatus(true);
			apiResponse.setMessage("Certificate Count");
			apiResponse.setResult(count.toString());
			return apiResponse.toString();
		} catch (Exception e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/getRevokeReasons/", produces = "application/json")
	public String getRevokeReasons() {
		APIResponse revokeReasons = new APIResponse();
		String reasons = raServiceIfaceImpl.getRevokeReasons();
		revokeReasons.setStatus(true);
		revokeReasons.setMessage("Revoke reasons");
		revokeReasons.setResult(reasons);
		return revokeReasons.toString();
	}

	@GetMapping(value = "/getCertificateCountByDate", produces = "application/json")
	public String getCertificateCountByDate() {
		APIResponse apiResponse = new APIResponse();
		try {
			Integer count = raServiceIfaceImpl.getCertificateCountByDate();
			apiResponse.setStatus(true);
			apiResponse.setMessage("Certificate Count");
			apiResponse.setResult(count.toString());
			return apiResponse.toString();
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/getCertificateDetails/", produces = "application/json")
	public String getCertificateDetails() {
		APIResponse apiResponse = new APIResponse();
		try {
			String response = raServiceIfaceImpl.getCertificateDetails();
			apiResponse.setStatus(true);
			apiResponse.setMessage("Certificate Details");
			apiResponse.setResult(response);
			return apiResponse.toString();
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/getCertificateDetailsBySubscriberCertId/{id}/", produces = "application/json")
	public String getCertificateDetailsBySubscriberCertId(@PathVariable int id) {
		APIResponse apiResponse = new APIResponse();
		try {
			String response = raServiceIfaceImpl.getCertificateDetailsBySubscriberCertId(id);
			apiResponse.setStatus(true);
			apiResponse.setMessage("Certificate Details");
			apiResponse.setResult(response);
			return apiResponse.toString();
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/certificateLifeCycleLogs/", produces = "application/json")
	public String getCertificateLifeCycleLogs() {
		APIResponse certificateLifeCycleLogs = new APIResponse();
		try {
			String response = raServiceIfaceImpl.getCertificateLifecycleLogs();
			if (!response.isEmpty()) {
				certificateLifeCycleLogs.setStatus(true);
				certificateLifeCycleLogs.setMessage("Certificate iifecycle logs");
				certificateLifeCycleLogs.setResult(response);
				return certificateLifeCycleLogs.toString();
			} else {
				throw new RAServiceException("Logs not found");
			}
		} catch (RAServiceException e) {
			certificateLifeCycleLogs.setStatus(false);
			certificateLifeCycleLogs.setMessage(e.getMessage());
			return certificateLifeCycleLogs.toString();
		}
	}

	@GetMapping(value = "/certificateLifeCycleLogsBySubscriberId/{subscriberId}/", produces = "application/json")
	public String getCertificateLifeCycleLogsBySubscriberId(@PathVariable RAPKISubscriberdata subscriberId) {

		APIResponse apiResponse = new APIResponse();
		try {
			RAServiceAsserts.notNullorEmpty(subscriberId, "SubscriberId");
			String response = raServiceIfaceImpl.getCertificateLifeCycleLogsBySubscriberId(subscriberId);
			if (!response.isEmpty()) {
				apiResponse.setStatus(true);
				apiResponse.setMessage("Certificate lifecycle log");
				apiResponse.setResult(response);
				return apiResponse.toString();
			} else {
				throw new RAServiceException("Logs not found");
			}
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}
}
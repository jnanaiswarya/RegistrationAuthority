package com.dt.ra.service.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.dt.ra.service.enums.CertificateStatus;
import com.dt.ra.service.enums.CertificateType;
import com.dt.ra.service.enums.RevokeReason;

@Entity
@Table
public class RAPKISubscribercertificatedata implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private int subscriberCertId;
	@Column(unique = true, length = 50)
	private String pkiKeyId;
	@Column(unique = true, length = 4096)
	private String certificateData;
	@Column(length = 100)
	@Enumerated(EnumType.STRING)
	private CertificateStatus certificateStatus;
	@Column(length = 100)
	@Enumerated(EnumType.STRING)
	private CertificateType certificateType;
	@Column(unique = true, length = 50)
	private String certificateSerialNumber;
	@Column(length = 100)
	@Enumerated(EnumType.STRING)
	private RevokeReason revocationReason;
	@Column(length = 50)
	private String startDate;
	@Column(length = 50)
	private String endDate;
	@Column(length = 50)
	private String revocationDate;
	@Column(length = 50)
	private String creationDate;
	@Column(length = 50)
	private String modificationDate;
	@Column(length = 5)
	private int certificateId;

	@ManyToOne
	@JoinColumn(name = "subscriber_id", nullable = false)
	private RAPKISubscriberdata raPKISubscriberData;

	public RAPKISubscriberdata getRaPKISubscriberData() {
		return raPKISubscriberData;
	}

	public void setRaPKISubscriberData(RAPKISubscriberdata raPKISubscriberData) {
		this.raPKISubscriberData = raPKISubscriberData;
	}

	public int getSubscriberCertId() {
		return subscriberCertId;
	}

	public void setSubscriberCertId(int subscriberCertId) {
		this.subscriberCertId = subscriberCertId;
	}

	public String getPkiKeyId() {
		return pkiKeyId;
	}

	public void setPkiKeyId(String pkiKeyId) {
		this.pkiKeyId = pkiKeyId;
	}

	public String getCertificateData() {
		return certificateData;
	}

	public void setCertificateData(String certificateData) {
		this.certificateData = certificateData;
	}

	public CertificateStatus getCertificateStatus() {
		return certificateStatus;
	}

	public void setCertificateStatus(CertificateStatus certificateStatus) {
		this.certificateStatus = certificateStatus;
	}

	public CertificateType getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(CertificateType certificateType) {
		this.certificateType = certificateType;
	}

	public String getCertificateSerialNumber() {
		return certificateSerialNumber;
	}

	public void setCertificateSerialNumber(String certificateSerialNumber) {
		this.certificateSerialNumber = certificateSerialNumber;
	}

	public RevokeReason getRevocationReason() {
		return revocationReason;
	}

	public void setRevocationReason(RevokeReason revocationReason) {
		this.revocationReason = revocationReason;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(String modificationDate) {
		this.modificationDate = modificationDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getRevocationDate() {
		return revocationDate;
	}

	public void setRevocationDate(String revocationDate) {
		this.revocationDate = revocationDate;
	}

	public int getCertificateId() {
		return certificateId;
	}

	public void setCertificateId(int certificateId) {
		this.certificateId = certificateId;
	}

	@Override
	public String toString() {
		return "{" 
				+ "\"SerialNumber\"" 				+ ":" 	+ "\"" + certificateSerialNumber	+ "\"," 
				+ "\"CertificateStatus\""			+ ":"	+ "\"" + certificateStatus             	+ "\"," 
				+ "\"CertificateType\""				+ ":"	+ "\"" + certificateType               	+ "\","
				+ "\"StartDate\"" 						+ ":"	+ "\"" + startDate 							+ "\","
				+ "\"EndDate\""						+ ":" 	+ "\"" + endDate							+ "\","
				+ "\"ModificationDate\"" 			+ ":" 	+ "\""	+ modificationDate 			+ "\","
				+ "\"SubscriberCertId\"" 			+ ":" 	+"\""	+ certificateId 					+ "\","
				+ "\"SubscriberUsername\"" 	+ ":" 	+ "\"" + pkiKeyId 							+ "\""
				+ "}";
	}

}

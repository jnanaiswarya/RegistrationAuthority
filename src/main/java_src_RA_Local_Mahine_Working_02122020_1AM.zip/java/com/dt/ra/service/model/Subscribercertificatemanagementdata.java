package com.dt.ra.service.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Subscribercertificatemanagementdata {
	@Id
	@GeneratedValue
	private int certificateManagementId;
	@Column(length = 50)
	private String certificateSerialNumber;
	@Column(length = 50)
	private String coorelationId;
	@Column(length = 100)
	private String certificateStatus;
	@Column(length = 50)
	private String creationDate;

	@ManyToOne
	@JoinColumn(name = "subscriber_id", nullable = false)
	private RAPKISubscriberdata raPKISubscriberData;

	public RAPKISubscriberdata getRaPKISubscriberData() {
		return raPKISubscriberData;
	}

	public void setRaPKISubscriberData(RAPKISubscriberdata raPKISubscriberData) {
		this.raPKISubscriberData = raPKISubscriberData;
	}

	public int getCertificateManagementId() {
		return certificateManagementId;
	}

	public void setCertificateManagementId(int certificateManagementId) {
		this.certificateManagementId = certificateManagementId;
	}

	public String getCertificateSerialNumber() {
		return certificateSerialNumber;
	}

	public void setCertificateSerialNumber(String certificateSerialNumber) {
		this.certificateSerialNumber = certificateSerialNumber;
	}

	public String getCoorelationId() {
		return coorelationId;
	}

	public void setCoorelationId(String coorelationId) {
		this.coorelationId = coorelationId;
	}

	public String getCertificateStatus() {
		return certificateStatus;
	}

	public void setCertificateStatus(String certificateStatus) {
		this.certificateStatus = certificateStatus;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	@Override
	public String toString() {
		return "{" + "\"CertificateSerialNumber\"" + ":" + "\"" + certificateSerialNumber + "\","
				+ "\"CertificateStatus\"" + ":" + "\"" + certificateStatus + "\"," + "\"CreationDate\"" + ":" + "\""
				+ creationDate + "\"," + "\"SubscriberId\"" + ":" + "\"" + certificateManagementId + "\"" + "}";
	}

}

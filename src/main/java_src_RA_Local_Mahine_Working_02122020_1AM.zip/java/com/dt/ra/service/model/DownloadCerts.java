package com.dt.ra.service.model;

public class DownloadCerts {

	private String certificates;

	public String getCertificates() {
		return certificates;
	}

	public void setCertificates(String certificates) {
		this.certificates = certificates;
	}

	@Override
	public String toString() {
		return "{" + "\"certificate\":\"" + certificates + "\"" + "}";
	}

}

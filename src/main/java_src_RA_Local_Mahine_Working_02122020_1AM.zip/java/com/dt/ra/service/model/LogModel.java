package com.dt.ra.service.model;

public class LogModel {
	private String identifier;
	private String nin;
	private String correlationId;
	private String transactionId;
	private String startTime;
	private String endTime;
	private String geolocation;
	private String serviceName;
	private String transactionType;
	private String logMessage;
	private String logMessageType;
	private String callstack;
	private String checksum;

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getNin() {
		return nin;
	}

	public void setNin(String nin) {
		this.nin = nin;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getGeolocation() {
		return geolocation;
	}

	public void setGeolocation(String geolocation) {
		this.geolocation = geolocation;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getLogMessage() {
		return logMessage;
	}

	public void setLogMessage(String logMessage) {
		this.logMessage = logMessage;
	}

	public String getLogMessageType() {
		return logMessageType;
	}

	public void setLogMessageType(String logMessageType) {
		this.logMessageType = logMessageType;
	}

	public String getCallstack() {
		return callstack;
	}

	public void setCallstack(String callstack) {
		this.callstack = callstack;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	@Override
	public String toString() {
		return "{"
				+"\"identifier\""+":\""+identifier+"\","
				+"\"checksum\""+":\""+checksum+"\","
				+"\"transactionID\""+":\""+transactionId+"\","
				+"\"serviceName\""+":\""+serviceName+"\","
				+"\"startTime\""+":\""+startTime+"\","
				+"\"endTime\""+":\""+endTime+"\","
				+"\"logMessage\""+":\""+logMessage+"\","
				+"\"logMessageType\""+":\""+logMessageType+"\","
				+"\"transactionType\""+":\""+transactionType+"\","
				+"\"correlationID\""+":\""+correlationId+"\","
				+"\"nin\""+":\""+nin+"\","
				+"\"geoLocation\""+":\""+geolocation+"\","
				+"\"callstack\""+":"+callstack+""
				+ "}";
	}

}

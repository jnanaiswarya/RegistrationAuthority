package com.dt.ra.service.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CentralLogRepository extends JpaRepository<CentralLog, Integer> {

	public CentralLog findBycorelationId(String cid);

}

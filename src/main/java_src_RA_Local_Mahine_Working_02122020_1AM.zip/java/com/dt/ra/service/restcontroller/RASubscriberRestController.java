package com.dt.ra.service.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dt.ra.service.asserts.RAServiceAsserts;
import com.dt.ra.service.exception.RAServiceException;
import com.dt.ra.service.ifaceimplementation.RASubscriberServiceIfaceImpl;
import com.dt.ra.service.model.RAPKISubscriberdata;
import com.dt.ra.service.requestentity.SubscriberDataRequest;
import com.dt.ra.service.responseentity.APIResponse;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/ra/service/subscriber")
public class RASubscriberRestController {

	@Autowired
	RASubscriberServiceIfaceImpl subscriberServiceIfaceImpl;

	@PostMapping(value = "/enrollSubscriber", produces = "application/json", consumes = "application/json")
	public String enrollSubscriber(@RequestBody SubscriberDataRequest subscriberData) {
		APIResponse apiResponse = new APIResponse();
		try {
			System.out.println(subscriberData.toString());
			RAServiceAsserts.notNullorEmpty(subscriberData, "Request Body ");
			String response = subscriberServiceIfaceImpl.enrollSubscriber(subscriberData);
			System.out.println("ReqComp");
			if (response.equals("Success")) {
				apiResponse.setStatus(true);
				apiResponse.setMessage("Subscriber Enrollment Success");
				return apiResponse.toString();
			} else
				throw new RAServiceException("Subscriber Enrollment Failed");
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/getAllSubscriberDetails", produces = "application/json")
	public String getAllSubscriberDetails() {
		APIResponse apiResponse = new APIResponse();
		try {
			List<RAPKISubscriberdata> raSubscriberData = subscriberServiceIfaceImpl.getAllSubscriberDetails();
			apiResponse.setStatus(true);
			apiResponse.setMessage("Subscriber details");
			apiResponse.setResult(raSubscriberData.toString());
			return apiResponse.toString();
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/getSubscriberDetailsBySubscriberDigitalId/{subscriberDigitalId}", produces = "application/json")
	public String getSubscriberDetailsBySubscriberDigitalId(@PathVariable String subscriberDigitalId) {
		APIResponse apiResponse = new APIResponse();
		try {

			RAServiceAsserts.notNullorEmpty(subscriberDigitalId, "Subscriber Digital Id");
			RAPKISubscriberdata raSubscriberData = subscriberServiceIfaceImpl
					.getSubscriberDetailsBySubscriberDigitalId(subscriberDigitalId);
			apiResponse.setStatus(true);
			apiResponse.setMessage("Subscriber details");
			apiResponse.setResult(raSubscriberData.toString());
			return apiResponse.toString();
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/getSubscriberDetailsByOrganizationId/{organizationId}", produces = "application/json")
	public String getSubscriberDetailsByOrganizationId(@PathVariable int organizationId) {
		APIResponse apiResponse = new APIResponse();
		try {
			RAServiceAsserts.notNullorEmpty(organizationId, "OrganizatioId ");
			List<RAPKISubscriberdata> raSubscriberData = subscriberServiceIfaceImpl
					.getSubscriberDetailsByOrganizationId(organizationId);
			apiResponse.setStatus(true);
			apiResponse.setMessage("Subscriber details");
			apiResponse.setResult(raSubscriberData.toString());
			return apiResponse.toString();
		} catch (RAServiceException e) {
			apiResponse.setStatus(false);
			apiResponse.setMessage(e.getMessage());
			return apiResponse.toString();
		}
	}

	@GetMapping(value = "/getSubscriberCount", produces = "application/json")
	public String getSubscriberCount() {
		APIResponse usersCount = new APIResponse();
		Integer count = subscriberServiceIfaceImpl.getSubscriberCount();
		usersCount.setStatus(true);
		usersCount.setMessage("Subscriber count");
		usersCount.setMessage(count.toString());
		return usersCount.toString();
	}
}

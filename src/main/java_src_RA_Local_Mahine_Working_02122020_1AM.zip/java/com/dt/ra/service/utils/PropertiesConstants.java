package com.dt.ra.service.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class PropertiesConstants implements CommandLineRunner {

	@Autowired
	PropertiesConfiguration propertiesConfiguration;

	public static String PKIURL;
	public static String ISSUECERTIFICATECALLBACKURL;

	// Mail
	public static String SPRINGMAILHOST;
	public static int SPRINGMAILPORT;
	public static String SPRINGMAILUSERNAME;
	public static String SPRINGMAILPASSWORD;

	@Override
	public void run(String... args) throws Exception {
		PKIURL = propertiesConfiguration.getPki();
		ISSUECERTIFICATECALLBACKURL = propertiesConfiguration.getIssuecertificatecallbackurl();
		SPRINGMAILHOST = propertiesConfiguration.getSpringmailhost();
		SPRINGMAILPORT = propertiesConfiguration.getSpringmailport();
		SPRINGMAILUSERNAME = propertiesConfiguration.getSpringmailusername();
		SPRINGMAILPASSWORD = propertiesConfiguration.getSpringmailpassword();
	}
}

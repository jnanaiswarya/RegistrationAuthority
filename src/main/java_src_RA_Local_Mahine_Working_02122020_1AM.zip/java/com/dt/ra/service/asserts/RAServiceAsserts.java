package com.dt.ra.service.asserts;

import com.dt.ra.service.exception.RAServiceException;

public class RAServiceAsserts {

	public static void notNullorEmpty(String orgumentValue, String orgumentName) throws RAServiceException {
		if (orgumentValue == null || orgumentValue.isEmpty()) {
			throw new RAServiceException(orgumentName + " should not be null or empty");
		}
	}

	public static void notNullorEmpty(Object orgumentValue, String orgumentName) throws RAServiceException {
		if (orgumentValue == null) {
			throw new RAServiceException(orgumentName + " should not be null or empty");
		}
	}

	public static void notNullorEmpty(Object raSubscriberData, String orgumentName, String orgumentName2)
			throws RAServiceException {
		if (raSubscriberData == null) {
			throw new RAServiceException(orgumentName + orgumentName2);
		}
	}
	
	public static void notNullorEmpty(int size, String orgumentName)
			throws RAServiceException {
		if (size == 0) {
			throw new RAServiceException(orgumentName + "not found");
		}
	}
	
	public static void notNullorEmpty(String orgumentName)
			throws RAServiceException {
			throw new RAServiceException(orgumentName + "not found");
	}
}
